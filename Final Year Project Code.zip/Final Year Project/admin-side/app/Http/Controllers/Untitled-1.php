<form method="POST"  action="update_product">
@csrf

<input type="hidden" name="id" value="{{$data['id']}}">



<label>Image Path</label>
<input type="text" name="product_image_path" value="{{$data['product_image_path']}}"><br><br>

<label>Name </label>
<input type="text" name="name" value="{{$data['name']}}" disabled><br><br>

<label>Description </label>
<input type="text" name="description" value="{{$data['description']}}"><br><br>

<label> Price</label>
<input type="number" name="price" value="{{$data['price']}}"><br><br>

<label>Quantity </label>
<input type="number" name="quantity" value="{{$data['quantity']}}"><br><br>

<label>Manufacturing Date </label>
<input type="date" name="manufacture" value="{{$data['manufacture']}}"><br><br>

<label>Expiry date </label>
<input type="date" name="expire" value="{{$data['expire']}}" ><br><br>
                                    
 <button type="submit">update</button>