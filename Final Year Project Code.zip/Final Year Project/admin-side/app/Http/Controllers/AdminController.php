<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use App\Models\Pending_register;
use App\Models\User;
use App\Models\Block_user;
use App\Models\Order;
use App\Models\Order_item;
use View;
use App\Models\Cancel_order;
//use App\Models\Pending_order;
use Illuminate\Support\Str;
use Hash;
class AdminController extends Controller
{
    //


    
    public function  addproduct_page()
        {
          return view('addproduct');
        }





    public function addproduct(Request $request)
    {
         $request->validate([
        'name'=>'required',
        'description'=>'required',
        'category'=>'required',
        'price'=>'required',
        'quantity'=>'required',
        'manufacture'=>'required|date|date_format:Y-m-d|before:expire',
        'expire'=>'required|date|date_format:Y-m-d|after:manufacture',
        'image_path'=>'required',
        ]);   
        $product = new Product();
        
        $product->serial_no = Str::uuid()->toString();
        $product->name = $request->name;
        $product->description = $request->description;
        $product->category = $request->category;
        $product->price =$request->price;
        $product->quantity = $request->quantity;
        $product->manufacture = $request->manufacture;
        $product->expire = $request->expire;
        $product->product_image_path = $request->image_path;
        $res = $product->save();
          if($res){
              return redirect('show_product');
          }else{
              return back()->with('fail','product not saved');
          }
     
     
        // if($request->hasfile('image')){
      
      //   $file = $request->file('image');
      
      //   $extension = $file->getClientOriginalExtension();
      //   $filename = time().'.'.$extension;
      //   $file->move('uploads/product/',$filename);
      //   $product->product_image_path = $filename;
      //     }
      //   $res = $product->save();
      //   if($res){
      //       return redirect('show_product');
      //   }else{
      //       return back()->with('fail','product not saved');
      //   }
      
    
    }








    public function showproduct(Request $req)
    { 
      
      $search = $req['search'] ?? "";
      if($search != ""){
          //where clause
          $products = Product::where('name','LIKE',"%$search%")->orwhere('category','LIKE',"%$search%")->get();
      }else{          
      $products = Product::all();
      }
  
      $data = compact('products');
       return view('product_list')->with($data);
      }
      
    
    public function show_product_tablet(Request $req)
    {
        $search = $req['search'] ?? "";

        $products = Product::where('category', 'tablet')->get();
        $data = compact('products','search');
        return view('product_list')->with($data);
    }
    
    public function show_product_syrup(Request $req)
    {
        $search = $req['search'] ?? "";

        $products = Product::where('category', 'syrup')->get();
        $data = compact('products','search');
        return view('product_list')->with($data);
    }
    
    public function show_product_injection(Request $req)
    {
        $search = $req['search'] ?? "";

        $products = Product::where('category', 'injection')->get();
        $data = compact('products','search');
        return view('product_list')->with($data);
    }
    
    public function show_product_drink(Request $req)
    {
        $search = $req['search'] ?? "";

        $products = Product::where('category', 'drink')->get();
        $data = compact('products','search');
        return view('product_list')->with($data);
    }
    
    public function show_product_babystuff(Request $req)
    {
        $search = $req['search'] ?? "";

        $products = Product::where('category', 'baby_Stuff')->get();
        $data = compact('products','search');
        return view('product_list')->with($data);
    }






    public function deleteproduct($name)
    { 
        DB::delete('delete from products where serial_no = ?',[$name]);        
       return redirect('/show_product');
    }


    



    public function show_product($id)
    { 
      $data = Product::find($id);
      return view('edit_product',['data'=>$data]);  
    }
   
   




    public function update_product(Request $request){ 
     
    $data = Product::find($request->id);   

     $data->product_image_path = $request->product_image_path;
     $data->description = $request->description;
     $data->price = $request->price;
     $data->quantity = $request->quantity;
     $data->manufacture = $request->manufacture;
     $data->expire = $request->expire;
    $data->save();
    return redirect('show_product');
    }
    





// orders controller


    public function order_list()  
        { 
            $orders       = Order::all();
            $order_items  = Order_item::all();
            return view::make('order-list')->with(compact('orders','order_items'));
        }   
    
    
    public function cancel_order($id)  
        { 
          
          $order = Order::find($id);
          // $order_pro = Order_item::where('order_id',$order->id)->get()->all();
          // foreach($order_pro as $pro){
          // $orders = Order_item::where('prod_id',$pro)->get->all();
          // echo $orders;
          //  }
       

          
          
          if(DB::table('cancel_orders')->insert([

                'id'=>$order->id,
                'user_id'=>$order->user_id,
                'f_name' =>$order->f_name,
                'l_name' =>$order->l_name,
                'phone_number' =>$order->phone_number,
                'address1' =>$order->address1,
                'address2' =>$order->address2,
                'city' =>$order->city,
                'total' =>$order->total,
                ]))
                {
                
                
                  $prod->quantity = $prod->quantity - $item->quantity;
                  $prod->update();
            
            
                  DB::table('orders')->where('id','=', $id)->delete();
                  DB::table('order_items')->where('order_id','=', $id)->delete();
                  return redirect('show_orders')->with('Your order is cancel');
              }
              else
              { 
                  return back()->with('something wrong with your cancellation the order');
              }
        }

    public function order_confirm($id){

         
          $order = Order::find($id);
 
          if(DB::table('pending_orders')->insert([

                'id'=>$order->id,
                'serial_no'=>$order->order_serial_no,
                'user_id'=>$order->user_id,
                'product_id'=>$order->product_id,
                'product_image_path'=>$order->product_image_path,
                'name' =>$order->name,
                'price' =>$order->unit_price,
                'quantity' =>$order->quantity,
                'total' =>$order->total,
                'manufacture' =>$order->manufacture,
                'expire' =>$order->expire,
                ]))
                {
                  DB::table('orders')->where('id','=', $id)->delete();
                  return redirect('show_orders')->with('Your order is on progress');
              }
              else
              { 
                  return back()->with('something your with your cart');
              }} 



    public function show_cancel_orders(){
        $order = cancel_Order::all();
        return view('show_cancel_orders',['orders'=>$order]);
      }
    
    public function Delete_Cancel_order($id){

      $order = Cancel_order::where('id',$id)->get(); 
        DB::table('cancel_orders')->where('id','=', $id)->delete();
      return back()->with('Record of order is delete permanently');
      }
    
           
    //  public function pending_orders(){

    //             $order = pending_Order::all();
    //             return view('show_pending_orders',['orders'=>$order]);


                
    //  }   

     public function order_delievered($id){
       return $id;

     }






// user controllers

    public function show_user_req()
    {
    
      $user = Pending_register::all();
      return view('new-requests',['users'=>$user]);
     
    }

    
    public function accept_user($id)
    {
      
      $user = Pending_register::find($id);
      
      if(DB::table('users')->insert([

            'id'=>$user->id,
            'registration_no'=>$user->registration_no,
            'f_name'=>$user->f_name,
            'l_name'=>$user->l_name,
            'email' =>$user->email,
            'password' =>$user->password,
            'city' =>$user->city,
            
            ]))
            {
              DB::table('pending_registers')->where('id','=', $id)->delete();
              return redirect('new-requests');
          }
          else
          { 
              return back()->with('something your with user registration');
          }
    } 
    


    public function show_users()
    {
      $user = User::all();
      return view('show_users',['users_data'=>$user]);
    }


    public function block($id)
    {
    $user = User::find($id);
   

      if(DB::table('block_users')->insert([

            'id'=>$user->id,
            'registration_no'=>$user->registration_no,
            'f_name'=>$user->f_name,
            'l_name'=>$user->l_name,
            'email' =>$user->email,
            'password' =>$user->password,
            'city' =>$user->city,
            
            ]))
            {
              DB::table('users')->where('id','=', $id)->delete();
              return redirect('show_users');
          }
          else
          { 
              return back()->with('something wrong with user block');
          }
    }

    public function unblock($id)
    {
      $user = Block_user::find($id);
      
      if(DB::table('users')->insert([

            'id'=>$user->id,
            'registration_no'=>$user->registration_no,
            'f_name'=>$user->f_name,
            'l_name'=>$user->l_name,
            'email' =>$user->email,
            'password' =>$user->password,
            'city' =>$user->city,
            
            ]))
            {
              DB::table('block_users')->where('id','=', $id)->delete();
              return redirect('block_users');
          }
          else
          { 
              return back()->with('something wrong to block');
          }
    }
    
    


    public function show_block_users()
    {
      $user = Block_user::all();
      return view('block-users',['users_data'=>$user]);
    }

    public function cancel_sign_up_request($id)
    {
      
      DB::delete('delete from pending_registers where id = ?',[$id]);        
      return redirect('/new-requests');
    }
    




    
    public function edit_user($id)
    { 
      $data = User::find($id);
      return view('edit_user',['data'=>$data]);        
    }






    public function update_user(Request $request){ 
    
      
     $data = User::find($request->id);
     $request->validate([
      'f_name'=>'required',
      'l_name'=>'required',
      'email'=>'required|email|unique:users',
      'password'=>'required',
      'city'=>'required',
    ]);
    
      $data->f_name = $request->f_name;
      $data->l_name = $request->l_name;
      $data->email = $request->email;
      $data->password = Hash::make($request->password);
      $data->city = $request->city;
      
     $data->save();

    return redirect('show_users');
    }





    public function deleteuser($id)
    {     
    DB::delete('delete from users where id = ?',[$id]);    
       return redirect('/show_users');
    }
    



    public function index()
    {

      $data = Product::all();
      return view('index',['product_data'=>$data]);

       // return view('index');
    }



    
}
