<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('complete_orders', function (Blueprint $table) {
            $table->id();
            $table->string('serial_no');
            $table->string('product_id');
            $table->string('user_id');
            $table->string('product_image_path');
            $table->string('name');
            $table->float('price');
            $table->integer('quantity');
            $table->float('total');
            $table->date('manufacture');
            $table->date('expire');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('complete_orders');
    }
};
