<?php
include "dbbcon.php";
$id=$_GET['Student_ID'];
$dell="DELETE FROM `Student_info` WHERE Student_ID='$id'";
$v11=mysqli_query($conn,$dell);
if($v11)
{
	header('location:Sawww.php');
}
else
{
	Echo "Data not delete";
}
?>