<html>
<body>
<a href="Edittt.php"></a>
<table border="2">
	<tr>
		<th>ID</th>
		<th>First_Name</th>
		<th>Last_Name</th>
		<th>Class</th>
		<th>Roll_No</th>
		<th>CGPA</th>
		<th>City</th>
		<th>Contect</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
<?php
include ("dbbcon.php");
?>
<?php
$vv="SELECT * FROM Student_info";
$resullt=mysqli_query($conn,$vv);
while($data=mysqli_fetch_array($resullt))
{
	$test = $data['Student_ID'];
	ECHO "<tr><td>".$data['Student_ID']."</td>
	<td>".$data['First_Name']."</td>
	<td>".$data['Last_Name']."</td>
	<td>".$data['Class']."</td>
	<td>".$data['Roll_No']."</td>
	<td>".$data['CGPA']."</td>
	<td>".$data['City']."</td>
	<td>".$data['Contect']."</td>";
	ECHO '<td><a href="Edittt.php?Student_ID='.$test.'" >Edit</a></td>';
	ECHO '<td><a href="Deleteee.php?Student_ID='.$test.'" >Delete</a></td>';
}
?>
</table>