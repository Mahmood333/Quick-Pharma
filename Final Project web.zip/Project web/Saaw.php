<html>
<body>
<a href="Editttt.php"></a>
<table border="2">
	<tr>
		<th>ID</th>
		<th>First_Name</th>
		<th>Last_Name</th>
		<th>CNIC</th>
		<th>Experience</th>
		<th>Email</th>
		<th>City</th>
		<th>Contect</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
<?php
include ("dbbbcon.php");
?>
<?php
$x="SELECT * FROM `Teacher_info`";
$resulltt=mysqli_query($connn,$x);
while($data=mysqli_fetch_array($resulltt))
{
	$test = $data['Teacher_ID'];
	ECHO "<tr><td>".$data['Teacher_ID']."</td>
	<td>".$data['First_Name']."</td>
	<td>".$data['Last_Name']."</td>
	<td>".$data['CNIC']."</td>
	<td>".$data['Experience']."</td>
	<td>".$data['Email']."</td>
	<td>".$data['City']."</td>
	<td>".$data['Contect_no']."</td>";
	ECHO '<td><a href="Editttt.php?Teacher_ID='.$test.'" >Edit</a></td>';
	ECHO '<td><a href="Deleteet.php?Teacher_ID='.$test.'" >Delete</a></td>';
}
?>
</table>