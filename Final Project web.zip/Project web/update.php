<?php
include ('dbbcon.php');
$First_Name=$_GET['fname'];
$Last_Name=$_GET['lname'];
$Class=$_GET['class'];
$Roll_No=$_GET['roll'];
$CGPA=$_GET['gppa'];
$City=$_GET['city'];
$Contect=$_GET['contect'];
$dee =  $_GET['id'];
$query = "update student_info set First_Name='$First_Name', Last_Name='$Last_Name', Class='$Class',
Roll_No='$Roll_No', CGPA='$CGPA', city='$City', Contect='$Contect' where Student_ID='$dee'";
mysqli_query($conn,$query)
?>
<html>
	<head>
	<title>Update</title>
	<style>
	 .cc{
		 font-size:60px;
	 }
	</style>
	<head>
	<body>
	   
	   <table cellspacing="0" align="center" style="background-color:lightgray">
	     <tr>
		     <th style="color:Green" class="cc"><?php echo "Congratulations...!"?></th>
	     </tr>
		 <tr>
		    <th style="color:blue"><?php echo "Data Update Successfully..."?></th>
	     </tr>
		 <tr>
			<th><a href="Menu.html"><input type="Submit" Value="Go to Menu" ></a></th>
		 </tr>
	   </table>
	   
	</body>
	</html>
	