<?PHP
include('dbbcon.php');
//Step:01 Data fom URL
$dee =  $_GET['Student_ID'];
//Step:02 Fetch data from Database as in List View
$qry = "SELECT * FROM Student_info WHERE Student_ID='$dee'";
$data = mysqli_query($conn,$qry);
while($data_view = mysqli_fetch_assoc($data))
{	
?>
<form Action="update.php" method="GET">
<table>
	<tr>
		<td><b>Student_ID</b></td>
		<td><input type="text" name="id" value="<?PHP ECHO $data_view['Student_ID']; ?>"></td>
	</tr>
	<tr>
		<td><b>First_Name</b></td>
		<td><input type="text" name="fname" value="<?PHP ECHO $data_view['First_Name']; ?>"></td>
	</tr>
	<tr>
		<td><b>Last_Name</b></td>
		<td><input type="text" name="lname" value="<?PHP ECHO $data_view['Last_Name']; ?>"></td>
	</tr>	
	<tr>
		<td><b>Class</b></td>
		<td><input type="text" name="class" value="<?PHP ECHO $data_view['Class']; ?>"></td>
	</tr>
	<tr>
		<td><b>Roll_No</b></td>
		<td><input type="text" name="roll" value="<?PHP ECHO $data_view['Roll_No']; ?>"></td>
	</tr>	
	<tr>
		<td><b>CGPA</td>
		<td><input type="text" name="gppa" value="<?PHP ECHO $data_view['CGPA']; ?>"></td>
	</tr>
	<tr>
		<td><b>City</td>
		<td><input type="text" name="city" value="<?PHP ECHO $data_view['City']; ?>"></td>
	</tr>
	<tr>
		<td><b>Contect</td>
		<td><input type="text" name="contect" value="<?PHP ECHO $data_view['Contect']; ?>"></td>
	</tr>
	<tr>
		<td><input type="Submit" value="Update"></td>
	</tr>
<?php
} 
?>
</table>
</form>