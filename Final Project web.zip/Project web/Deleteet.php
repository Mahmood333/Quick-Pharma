<?php
include "dbbbcon.php";
$idd=$_GET['Teacher_ID'];
$delll="DELETE FROM `Teacher_info` WHERE Teacher_ID='$idd'";
$v111=mysqli_query($connn,$delll);
if($v111)
{
	header('location:Saaw.php');
}
else
{
	Echo "Data not delete";
}
?>