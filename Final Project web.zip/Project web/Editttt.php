<?PHP
include('dbbbcon.php');
//Step:01 Data fom URL
$dee =  $_GET['Teacher_ID'];
//Step:02 Fetch data from Database as in List View
$qry = "SELECT * FROM Teacher_info WHERE Teacher_ID='$dee '";
$data = mysqli_query($connn, $qry);
while($data_view = mysqli_fetch_assoc($data))
{
?>
<form action="updatee.php"method="GET">
<table>
	<tr>
		<td><b>Teacher_ID</b></td>
		<td><input type="text" name="id" value="<?PHP ECHO $data_view['Teacher_ID']; ?>"></td>
	</tr>
	<tr>
		<td><b>First_Name</b></td>
		<td><input type="text" name="fname" value="<?PHP ECHO $data_view['First_Name']; ?>"></td>
	</tr>
	<tr>
		<td><b>Last_Name</b></td>
		<td><input type="text" name="lname" value="<?PHP ECHO $data_view['Last_Name']; ?>"></td>
	</tr>	
	<tr>
		<td><b>CNIC</b></td>
		<td><input type="text" name="cnic" value="<?PHP ECHO $data_view['CNIC']; ?>"></td>
	</tr>
	<tr>
		<td><b>Experience</b></td>
		<td><input type="text" name="exp" value="<?PHP ECHO $data_view['Experience']; ?>"></td>
	</tr>	
	<tr>
		<td><b>Email</td>
		<td><input type="text" name="email" value="<?PHP ECHO $data_view['Email']; ?>"></td>
	</tr>
	<tr>
		<td><b>City</td>
		<td><input type="text" name="city" value="<?PHP ECHO $data_view['City']; ?>"></td>
	</tr>
	<tr>
		<td><b>Contect_no</td>
		<td><input type="text" name="contect" value="<?PHP ECHO $data_view['Contect_no']; ?>"></td>
	</tr>
	<tr>
		<td><input type="Submit" value="Update"></td>
	</tr>
<?php
} 
?>
</table>
</form>