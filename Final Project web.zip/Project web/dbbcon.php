<?php
$db_host="localhost";
$db_text="root";
$db_pass="";
$db_Name="StudentMSS";
$conn=mysqli_connect($db_host,$db_text,$db_pass,$db_Name);
?>
