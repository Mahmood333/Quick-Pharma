<?php
include("dbbcon.php");
$First_Name=$_GET['fname'];
$Last_Name=$_GET['lname'];
$Class=$_GET['class'];
$Roll_No=$_GET['roll'];
$CGPA=$_GET['gpa'];
$City=$_GET['city'];
$Contect=$_GET['contact'];
$insert="insert into Student_info(First_Name,Last_Name,Class,Roll_No,CGPA,City,Contect)
values('$First_Name','$Last_Name','$Class','$Roll_No',$CGPA,'$City','$Contect')";
mysqli_query($conn,$insert);
?>
<html>
	<head>
	<title>Update</title>
	<style>
	 .cc{
		 font-size:60px;
	 }
	</style>
	<head>
	<body>
	   
	   <table cellspacing="0" align="center" style="background-color:lightgray">
	     <tr>
		     <th style="color:Green" class="cc"><?php echo "Congratulations...!"?></th>
	     </tr>
		 <tr>
		    <th style="color:blue"><?php echo "Data Saved Successfully..."?></th>
	     </tr>
		 <tr>
			<th><a href="Menu.html"><input type="Submit" Value="Go to Menu" ></a></th>
		 </tr>
	   </table>
	   
	</body>
	</html>
















