<?php
include("dbbbcon.php");
$First_Name=$_GET['fname'];
$Last_Name=$_GET['lname'];
$CNIC=$_GET['cnic'];
$Experience=$_GET['exp'];
$Email=$_GET['email'];
$City=$_GET['city'];
$Contact=$_GET['Contact'];
$slv="insert into Teacher_info(First_Name,Last_Name,CNIC,Experience,Email,City,Contect_no)
values('$First_Name','$Last_Name','$CNIC','$Experience','$Email','$City','$Contact')";
mysqli_query($connn,$slv);
?>
<html>
	<head>
	<title>Update</title>
	<style>
	 .cc{
		 font-size:60px;
	 }
	</style>
	<head>
	<body>
	   
	   <table cellspacing="0" align="center" style="background-color:lightgray">
	     <tr>
		     <th style="color:Green" class="cc"><?php echo "Congratulations...!"?></th>
	     </tr>
		 <tr>
		    <th style="color:blue"><?php echo "Data Saved Successfully..."?></th>
	     </tr>
		 <tr>
			<th><a href="Menu.html"><input type="Submit" Value="Go to Menu" ></a></th>
		 </tr>
	   </table>
	   
	</body>
	</html>
















