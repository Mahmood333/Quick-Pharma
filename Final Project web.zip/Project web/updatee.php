<?php
include ('dbbbcon.php');
$First_Name=$_GET['fname'];
$Last_Name=$_GET['lname'];
$Cnic=$_GET['cnic'];
$Exp=$_GET['exp'];
$Email=$_GET['email'];
$City=$_GET['city'];
$Contect=$_GET['contect'];


$dee =  $_GET['id'];
$query = "update Teacher_info set First_Name='$First_Name', Last_Name='$Last_Name', CNIC='$Cnic',
Experience='$Exp', city='$City', Contect_No='$Contect' where Teacher_ID='$dee'";
mysqli_query($connn,$query)
?>
<html>
	<head>
	<style>
	 .cc{
		 font-size:60px;
	 }
	</style>
	<head>
	<body>
	   
	   <table cellspacing="0" align="center" style="background-color:lightgray">
	     <tr>
		     <th style="color:Green" class="cc"><?php echo "Congratulations...!"?></th>
	     </tr>
		 <tr>
		    <th style="color:blue"><?php echo "Data Update Successfully..."?></th>
	     </tr>
		 <tr>
			<th><a href="Menu.html"><input type="Submit" Value="Go to Menu" ></a></th>
		 </tr>
	   </table>
	   
	</body>
	</html>
	